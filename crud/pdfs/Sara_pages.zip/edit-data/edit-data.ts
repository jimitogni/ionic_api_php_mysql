import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SQLite, SQLiteObject } from "@ionic-native/sqlite";
import { Toast } from "@ionic-native/Toast"
import { THROW_IF_NOT_FOUND } from '@angular/core/src/di/injector';

/**
 * Generated class for the EditDataPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-edit-data',
  templateUrl: 'edit-data.html',
})
export class EditDataPage {

  dados = {id: 0, data: "", tipo: "", descricao: "", saldo: 0}

  constructor(public navCtrl: NavController, public navParams: NavParams, private sqLite: SQLite, private toast: Toast) {
    this.pegaDadoAtual(navParams.get("id"))
  }

  pegaDadoAtual(id){
    this.sqLite.create({
      name: "ionic.db",
      location: "default"
    }).then((db: SQLiteObject) => {
      db.executeSql('SELECT * FROM gastos WHERE id = ?', [id])
        .then(res => {
          if(res.rows.length > 0) {
            this.dados.id = res.rows.item(0).id;
            this.dados.data = res.rows.item(0).data;
            this.dados.tipo = res.rows.item(0).tipo;
            this.dados.descricao = res.rows.item(0).descricao;
            this.dados.saldo = res.rows.item(0).valor;
        }
      })
    })
  }
}
