import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SQLite, SQLiteObject } from "@ionic-native/sqlite";
import { Toast } from "@ionic-native/Toast"
/**
 * Generated class for the AddDataPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-data',
  templateUrl: 'add-data.html',
})
export class AddDataPage {
  dados = {data: "", tipo: "", descricao: "", saldo: ""}

  constructor(public navCtrl: NavController, public navParams: NavParams, private sqLite: SQLite, private toast: Toast) {
  }

  salvaDados(){
    this.sqLite.create({
      name: "ionic.db",
      location: "default"
    }).then((db: SQLiteObject) => {
      db.executeSql('INSERT INTO gastos VALUES (NULL, ?, ?, ?, ?)',[this.dados.data, this.dados.tipo, this.dados.descricao, this.dados.saldo])
      .then (res => {
        console.log(res);
        this.toast.show('Incluido com sucesso', '5000', 'center').subscribe(
          toast => {
            this.navCtrl.popToRoot();
          }
        );
      })
      .catch (e => {
        console.log(e);
        this.toast.show(e, "5000", "center").subscribe(
          toast=> {
            console.log(e);
          }
        );
      })
    })
    .catch (e => {
      console.log(e);
      this.toast.show(e, "5000", "center").subscribe(
        toast=> {
          console.log(e);
        }
      );
    });
  }

}
